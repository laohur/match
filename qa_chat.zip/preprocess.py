"处理文本"
import argparse
import torch
import transformer.Constants as Constants
import json
import math
from time import time
import os
from Util import *


def main():
    # dir = "../data/tb"
    dir = "../data/qa_data"
    parser = argparse.ArgumentParser()
    parser.add_argument('-train_src', default=dir + "/train_src.txt")
    parser.add_argument('-train_tgt', default=dir + "/train_tgt.txt")
    parser.add_argument('-valid_src', default=dir + "/valid_src.txt")
    parser.add_argument('-valid_tgt', default=dir + "/valid_tgt.txt")
    parser.add_argument('-save_dir', default="data")
    parser.add_argument('-max_len', '--max_word_seq_len', type=int, default=12)
    parser.add_argument('-min_word_count', type=int, default=5)
    parser.add_argument('-keep_case', action='store_true', default=False)
    parser.add_argument('-share_vocab', action='store_true', default=True)
    parser.add_argument('-vocab', default=None)

    args = parser.parse_args()
    args.max_token_seq_len = args.max_word_seq_len + 2  # include the <s> and </s>

    # Training set

    train_src_word_insts = load_file(args.train_src, args.max_word_seq_len, args.keep_case, begin=0, end=300000)
    train_tgt_word_insts = load_file(args.train_tgt, args.max_word_seq_len, args.keep_case, begin=0, end=300000)

    if len(train_src_word_insts) != len(train_tgt_word_insts):
        print('[Warning] 训练集源标句子数量不等,将被截断' + args.train_src, len(train_src_word_insts), args.train_tgt, len(train_tgt_word_insts))
        min_inst_count = min(len(train_src_word_insts), len(train_tgt_word_insts))
        train_src_word_insts = train_src_word_insts[:min_inst_count]
        train_tgt_word_insts = train_tgt_word_insts[:min_inst_count]

    # Remove empty instances
    train_src_word_insts, train_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(train_src_word_insts, train_tgt_word_insts) if s and t]))

    # Validation set
    valid_src_word_insts = load_file(args.valid_src, args.max_word_seq_len, args.keep_case, begin=0, end=-1)
    valid_tgt_word_insts = load_file(args.valid_tgt, args.max_word_seq_len, args.keep_case, begin=0, end=-1)

    if len(valid_src_word_insts) != len(valid_tgt_word_insts):
        print('[Warning] 源标句子数量不等,将被截断')
        print(args.valid_src, len(valid_src_word_insts), args.valid_tgt, len(valid_tgt_word_insts))
        min_inst_count = min(len(valid_src_word_insts), len(valid_tgt_word_insts))
        valid_src_word_insts = valid_src_word_insts[:min_inst_count]
        valid_tgt_word_insts = valid_tgt_word_insts[:min_inst_count]

    # Remove empty instances
    valid_src_word_insts, valid_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(valid_src_word_insts, valid_tgt_word_insts) if s and t]))

    # Build vocabulary
    if args.vocab:
        predefined_data = torch.load(args.vocab)
        assert 'dict' in predefined_data

        print('[Info] 加载词典')
        src_word2idx = predefined_data['dict']['src']
        tgt_word2idx = predefined_data['dict']['tgt']
    else:
        if args.share_vocab:
            print('[Info] 构建共同词典')
            word2idx, frequency = build_vocab_idx(train_src_word_insts + train_tgt_word_insts, args.min_word_count)
            src_word2idx = tgt_word2idx = word2idx
            # print("word2idx", word2idx)
        else:
            print('[Info] 从源文本构建词典')
            src_word2idx, frequency = build_vocab_idx(train_src_word_insts, args.min_word_count)
            print('[Info] 从文本构建词典')
            tgt_word2idx, frequency = build_vocab_idx(train_tgt_word_insts, args.min_word_count)

    # word to index
    print('[Info] 源文本字典序列化')
    train_src_insts = convert_w2id_seq(train_src_word_insts, src_word2idx)
    valid_src_insts = convert_w2id_seq(valid_src_word_insts, src_word2idx)
    print("训练集源  train_src_insts", len(train_src_insts), "验证集源 valid_src_insts", len(valid_src_insts))

    print('[Info] 标文本字典序列化')
    train_tgt_insts = convert_w2id_seq(train_tgt_word_insts, tgt_word2idx)
    valid_tgt_insts = convert_w2id_seq(valid_tgt_word_insts, tgt_word2idx)
    print("训练集标  train_tgt_insts", len(train_tgt_insts), "验证集标 valid_tgt_insts", len(valid_tgt_insts))

    # for line in valid_tgt_insts:
    #     print(len(line),line)
    # 10[2, 1989, 159, 1858, 2587, 1, 2457, 2868, 2101, 3]
    # 17[2, 1989, 2667, 2402, 1169, 667, 1371, 1304, 1993, 285, 2879, 1131, 1, 1, 2404, 2101, 3]

    vocab = {
        'settings': vars(args),
        'frequency': frequency,
        'dict': {
            'src': src_word2idx,
            'tgt': tgt_word2idx}}

    # data = {
    #     'settings': args,
    #     'frequency': frequency,
    #     'dict': {
    #         'src': src_word2idx,
    #         'tgt': tgt_word2idx},
    #     'train': {
    #         'src': train_src_insts,
    #         'tgt': train_tgt_insts},
    #     'valid': {
    #         'src': valid_src_insts,
    #         'tgt': valid_tgt_insts}}

    path = args.save_dir + "/reader.json"
    with open(path, "w", encoding="utf-8") as f:  # 特殊字符有问题，仅供人类阅读
        json.dump(vocab, f, ensure_ascii=False)

    vocab = {
        'settings': args,
        'frequency': frequency,
        'dict': {
            'src': src_word2idx,
            'tgt': tgt_word2idx}}
    path = args.save_dir + "/reader.data"
    print('[Info] 保存词汇到', os.path.abspath(path))
    torch.save(vocab, path)

    data = {
        'train': {
            'src': train_src_insts,
            'tgt': train_tgt_insts},
        'valid': {
            'src': valid_src_insts,
            'tgt': valid_tgt_insts}}
    path = args.save_dir + "/train.data"
    print('[Info] 保存训练数据到', os.path.abspath(path))
    torch.save(data, path)
    print('[Info] Finished.')


if __name__ == '__main__':
    main()
